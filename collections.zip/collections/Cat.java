package com.cognixia.jump.salesforce.collections;

public class Cat implements Animal{

}
