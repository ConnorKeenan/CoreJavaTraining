package com.cognixia.jump.salesforce.collections;

public interface Animal {

}
