package com.cognixia.jump.salesforce.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;

public class CollectionsDemo {

	public static void main(String[] args) {
		
		// Wrapper Classes and Auto-boxing
		
		Integer integer;
		
		int i = 1;			Integer I = i;
		float f = 2.0f; 	Float F = f;
		double d = 3.0; 	Double D = d;
		char c = '4';		Character C = c; 
		boolean b = true;	Boolean B = b;
		
		String s = "5";
		
		// Extracting different data from Strings
		I = Integer.parseInt(s);
		System.out.println(I + I);
		
		// Pass by value or reference?
		Integer one = 1;
		Integer two = 2;
		
		changeInts(one, two);
		
		System.out.println(one + " " + two);
		
		// Unboxing
		int newInt = one.intValue();
		
		// Collections Framework has - Collection(I) && Map(I)

			// From Collection(I) - 
		
				// List(I) - can have dup. and has order
					// Implementing Classes:
					ArrayList<String> arrayList = new ArrayList<>(2);
					
					// starting size is 2 (default is 10)
					arrayList.add("Item 1");
					arrayList.add("Item2");
					// We filled the original Array inside the ArrayList
					arrayList.add("Item3");
					// What happens to dynamically resize
						// array1 is copied to array2
						// array2.length = array1.length+(.50)*array1.length
						// once copied, array 1 is destroyed
					
					// ArrayList methods
						// Constructors
							// No args - size 10, specify size int,
							// pass in another Collection and convert
					
						// add
						arrayList.add("e"); // adds to end
						arrayList.add(2, "I added in the middle"); // not end
						arrayList.addAll(arrayList); // add a whole collection
						
						arrayList.add("duplicate");
						arrayList.add("duplicate");
						arrayList.add("duplicate");
						
						System.out.println(arrayList);
						
						// remove
						arrayList.remove("e");
						System.out.println(arrayList);
						
						// access or get
						arrayList.get(4);
						
						// replace or update - .set()
//						arrayList.replaceAll(operator);
						arrayList.set(3, "Replaced");
						
						System.out.println(arrayList);
						
					// LinkedList
					LinkedList<String> linkedList = new LinkedList<>();
					
					//linkedList.get(1);
					
					// Polymorphism example
					
					LinkedList<String> l1 = new LinkedList<>();
					List<String> l2 = new LinkedList<>();
					Queue<String> l3 = new LinkedList<>();
					
					// add
					l1.add("1");
					
					// access 
					l1.get(0);
					
					// update
					l1.set(0, "0");
					System.out.println(l1);
					// remove
					l1.remove(0);
					System.out.println(l1);
					
					
				// Set(I)
					Set<String> set = new HashSet<>(arrayList);
					
					System.out.println(arrayList);
					System.out.println(set);
					
					
					// Convert an array into a collection with asList()
					Integer[] ints = {1, 2, 3, 4};
					List<Integer>lists = Arrays.asList(ints);
					Set<Integer> sets = new HashSet<>(lists);
					
					// add
					set.add("Hello");
					set.add("Goodbye");
					set.add("Hello");
					System.out.println(set);
					
					// get or access - you must iterate (loops, streams, etc.)
						// using an iterator
					Iterator<String> iter = set.iterator();
					
					while(iter.hasNext()) {
						if(iter.next().equals("Goodbye")) {
							System.out.println("We found it");
						}
					}
					// For each loop
					for(String string : set) {
						System.out.println(string);
					}
					
					// .forEach() Method using a method reference -> ::
					arrayList.forEach(System.out::println);
					set.forEach(System.out::println);
					
					
					// remove from set
					set.remove("Goodbye");
			
				// Queue(I)
					
					Queue<String> q1 = new LinkedList<>(arrayList);
					PriorityQueue<String> q2 = new PriorityQueue<>(arrayList);
					
					// Queue Methods
					
					q1.add("first");
					
					q2.add("first");
					q2.add("second");
					q2.add("five");
					
					// remove (from front) FIFO
					
					String store = q2.poll();
					q2.poll();
					
					
					System.out.println(q2);
					
					// ** covnert to array
//					String[] stringList = (String[]) arrayList.toArray();
			
				// Deque(I)
					
					Deque<String> deque = new LinkedList<>(arrayList);
					
					// methods
		
			// From Map(I)
				
				// HashMap(C)
				Map<Integer, String> hashMap = new HashMap<>();
				
					// methods
				//	adding
					hashMap.put(null, "Matthew");
					hashMap.put(2, "Brad");
					hashMap.put(3, "Clarence");
					hashMap.put(4, "Connor");
					hashMap.put(5, "Dennis");
					hashMap.putIfAbsent(5, "Overridden");
					
					// accessing or getting
					hashMap.get(3);
					
					// iterating through a map
					
					for(Integer in : hashMap.keySet()) {
						System.out.println(hashMap.get(in));
					}
					
		
					System.out.println(hashMap);
				// HashTable(C)
		
				// ConcurrentHashMap(C)
	}
	
	public static void changeInts(Integer one, Integer two) {
		one = Integer.valueOf(6);
		System.out.println(one);
	}

}
