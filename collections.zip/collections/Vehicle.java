package com.cognixia.jump.salesforce.collections;

public class Vehicle {

}
